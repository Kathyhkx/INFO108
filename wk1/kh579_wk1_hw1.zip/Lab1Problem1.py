#Project Name: Lab 1 Problem 1
#Date: 01/12/2017
#Programmer Name: Kexin Han
#Project Description: Calculate average of 5 float numbers
print("Please input 5 floats: ")
num1 = float(input("Number1: "))
num2 = float(input("Number2: "))
num3 = float(input("Number3: "))
num4 = float(input("Number4: "))
num5 = float(input("Number5: "))
#kh calculate average and store in a variable
average  = (num1 + num2 + num3 + num4 + num5) / 5
#kh print out value
print("The average is", average)
